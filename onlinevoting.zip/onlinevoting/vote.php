<?php
require_once"authentication.php";
require_once"auth.php";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/bootstrap.min.css">
</head>
<body>       
     <body background="plofilespc/vote.png">       
     <div class="text-center">
            <h1><font color="darkblue" size="5">Mobile and Online Voting System</h1></font>
              <hr>
             <?php
    include "header4.php";
    ?>
            <hr>
        
        <div class="text-light text-center "> 
        <h1 style="color:white; background-color: black;">On this Voting Pannel Choose the posts are below!</h1></Center>&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;
        </div></h1>
        <h2></h2>
        <div class="d-flex" style="justify-content:space-between; font:size 20; ">
        <h2>
          
        <?php
    include "connection.php";
$qr=mysqli_query($conn,"SELECT * From post");
while($res=mysqli_fetch_array($qr)){
echo" <a href='vote.php?post=$res[postId]' class='btn btn-outline-light btn-lg bg-primary'>$res[postName]</a> </li>";
}
?></h2></div>
        
        <section style="min-height:500px">
        <div class="m-3">
<?php
$id=$_SESSION['Current_User_Id'];
$check = mysqli_query($conn,"SELECT * FROM votte where postId='$_GET[post]' and votterId='$id'");
if(mysqli_num_rows($check)>0){
    echo " <b><font color=red>you have aleady vote on this position</b></font>";
}
else
{
    $sql =mysqli_query($conn,"SELECT * From candidate inner join post where post.postId=candidate.postId and candidate.postId='$_GET[post]' order by candidate.postId");
    echo"<div class='row'>";
    while( $row=mysqli_fetch_array($sql)){
    ?>
<div class="card p-1 m-1 col-sm-3 col-lg-5 col-md-1 ">
   <div class="img-responsive">&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;<h4><img src="plofilespc\<?=$row['plofile']?>" alt="image not found" width="200px"> 
  <b><?=$row['Firstname']?> <?=$row['LastName']?></b> 
  <a href="app.php?votecid=<?=$row['Id']?>&postId=<?=$_GET['post']?>&votterId=<?=$id?>" class="btn btn-success py-3 px-6" onclick="return confirm('are you sure you want to vote this candidate')" width="100px"> VOTE <?=$row['LastName']?> </a></td> </h4> 
</div></div>
<?php } 

}
?>

    </div>
</section>
    <?php
    include "footer2.php";
    ?>
</body>
</html>