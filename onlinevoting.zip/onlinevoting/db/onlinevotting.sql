-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 29, 2024 at 09:04 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `onlinevotting`
--

-- --------------------------------------------------------

--
-- Table structure for table `candidate`
--

CREATE TABLE `candidate` (
  `Id` int(20) NOT NULL,
  `Firstname` varchar(30) NOT NULL,
  `LastName` varchar(30) NOT NULL,
  `Age` int(30) NOT NULL,
  `postId` varchar(23) NOT NULL,
  `plofile` varchar(50) NOT NULL,
  `DateOfBirth` date NOT NULL,
  `NID` varchar(16) NOT NULL,
  `status` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `candidate`
--

INSERT INTO `candidate` (`Id`, `Firstname`, `LastName`, `Age`, `postId`, `plofile`, `DateOfBirth`, `NID`, `status`) VALUES
(1, 'JEREMY', 'NIYONZIMA', 22, '1', 'OP.jpg', '2001-12-02', '1200480135833094', 1),
(2, 'Kayiranga', 'Obed', 28, '2', 'rt.jpg', '1995-12-31', '1200180135833023', 1),
(3, 'Kananga', 'Emmy', 23, '1', 'Screenshot 2024-03-08 153107.png', '2001-12-31', '1200180135833094', 1),
(4, 'Uwase', 'Joana', 25, '3', 'FB_IMG_16977342516362626.jpg', '1999-01-02', '1999080135833087', 1),
(6, 'ndayisenga', 'leo', 25, '4', 'download.png', '1999-12-02', '199980135833089', 1),
(8, 'kayitesi', 'aline', 26, '6', 'IMG-20221219-WA0005.jpg', '1998-12-02', '199880135833094', 1),
(9, 'mugabo', 'jonas', 27, '5', 'download.png', '1999-12-02', '11995809353394', 1),
(10, 'Inshutiyase', 'Belyse', 23, '5', 'download.png', '2001-12-03', '1200180135833090', 1);

-- --------------------------------------------------------

--
-- Table structure for table `post`
--

CREATE TABLE `post` (
  `postId` int(20) NOT NULL,
  `postName` varchar(20) NOT NULL,
  `Description` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `post`
--

INSERT INTO `post` (`postId`, `postName`, `Description`) VALUES
(1, 'President', 'his excellence'),
(2, 'Prime-minister', 'President assistent'),
(3, 'Minister-health', 'ministry of health'),
(4, 'Minister-Sport', 'Minister in charge of Sport'),
(5, 'Minister-technology', 'ministry of ict and innovation'),
(6, 'cabinet affairs', 'ministry of foreign affairs rwanda');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `Id` int(11) NOT NULL,
  `userName` varchar(30) NOT NULL,
  `password` varchar(70) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`Id`, `userName`, `password`) VALUES
(4, 'group4@gmail.com', '$2y$10$CIBugLliSYKccgbqb5Tnv.N58uFTu7dgws2jGKO/2jnuW4W86nb6a');

-- --------------------------------------------------------

--
-- Table structure for table `votte`
--

CREATE TABLE `votte` (
  `Id` int(20) NOT NULL,
  `candidateId` int(20) NOT NULL,
  `votterId` int(20) NOT NULL,
  `postId` int(20) NOT NULL,
  `pts` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `votte`
--

INSERT INTO `votte` (`Id`, `candidateId`, `votterId`, `postId`, `pts`) VALUES
(1, 1, 7, 1, 1),
(2, 2, 7, 2, 1),
(3, 4, 7, 3, 1),
(4, 6, 7, 4, 1),
(5, 9, 7, 5, 1),
(6, 8, 7, 6, 1);

-- --------------------------------------------------------

--
-- Table structure for table `votters`
--

CREATE TABLE `votters` (
  `Id` int(11) NOT NULL,
  `NID` int(16) NOT NULL,
  `firstname` varchar(30) NOT NULL,
  `lastName` varchar(30) NOT NULL,
  `Age` int(3) NOT NULL COMMENT 'Date of Birth',
  `Date of Birth` date NOT NULL,
  `userName` varchar(200) NOT NULL,
  `password` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `votters`
--

INSERT INTO `votters` (`Id`, `NID`, `firstname`, `lastName`, `Age`, `Date of Birth`, `userName`, `password`) VALUES
(1, 2147483647, 'Inshutiyase', 'Belyse', 21, '2001-03-12', 'jeremisto1000@gmail.com', '$2y$10$CIBugLliSYKccgbqb5Tnv.N58uFTu7dgws2jGKO/2jnuW4W86nb6a'),
(7, 2147483647, 'karangwangwa', 'jerk', 23, '2001-01-02', 'tuyishimire45@gmail.com', '$2y$10$PBfy.NQEpKz7dwYC1gNX9esh.OzFOwNH3cNybUoQWyDag7JMZwQDW');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `candidate`
--
ALTER TABLE `candidate`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `post`
--
ALTER TABLE `post`
  ADD PRIMARY KEY (`postId`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `votte`
--
ALTER TABLE `votte`
  ADD PRIMARY KEY (`Id`),
  ADD KEY `candidateId` (`candidateId`),
  ADD KEY `votterId` (`votterId`),
  ADD KEY `postId` (`postId`);

--
-- Indexes for table `votters`
--
ALTER TABLE `votters`
  ADD PRIMARY KEY (`Id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `candidate`
--
ALTER TABLE `candidate`
  MODIFY `Id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `post`
--
ALTER TABLE `post`
  MODIFY `postId` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `votte`
--
ALTER TABLE `votte`
  MODIFY `Id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `votters`
--
ALTER TABLE `votters`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
