<?php
require_once"authentication.php";
require_once"auth.php";
?>
<?php
include "connection.php";
	if (isset($_POST['change'])) {
		$old_pass=mysqli_real_escape_string($conn,$_POST['oldpass']);
		$new_pass=mysqli_real_escape_string($conn,$_POST['psw1']);
		$re_pass=mysqli_real_escape_string($conn,$_POST['psw2']);
		$hashed=password_hash($new_pass, PASSWORD_DEFAULT);
		$a=$_SESSION['Current_User_Id'];
		$sel=mysqli_query($conn,"SELECT * FROM user where Id='$a'");
			$data=mysqli_fetch_array($sel);
			//password_verify($new_pass,$pass1)$old_pass==$pass1
                if (password_verify($old_pass,$data['password'])) {
					if ($new_pass==$re_pass) {
							$change=mysqli_query($conn,"UPDATE user set password='$hashed' where Id='$a'");
			                echo "<script>alert('Password is changed')</script>";
							echo "<script>window.location.href='admindashboard.php'</script>";
						}
						else
						{
							echo "<script>alert('New and retype password are not match')</script>";
						}
					}
		else
			{
				echo "<script>alert('Old password wrong ')</script>";
				echo "<script>window.location.href='changform.php'</script>";


		    }
	}
	?>