<?php
require_once"authentication.php";
require_once"auth.php";
include "connection.php";
$res=mysqli_fetch_array(mysqli_query($conn,"SELECT * FROM candidate Where Id='$_GET[editecid]'"));
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title></title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/bootstrap.min.css">
</head>
<body background="plofilespc/vote.png">       
     <div class="text-center">
            <h1><font color="darkblue" size="5">Mobile and Online Votting System</h1></font>
            <hr>
    <div class="m-3">
    <?php
    include "header1.php";
    ?>
    <hr>
<section style="min-height:500px">
    
    <div class="col-lg-6 col-sm-12 p-0">
        <div class="card m-3 p-5">
    <form action="app.php" enctype="multipart/form-data" method="post">
  <h3>Update Candidate</h3>
  <input type="hidden" name="candidateId" value="<?=$_GET['editecid']?>">
  First name <sup class="text-danger">*</sup> <input type="text" class="form-control" required name="Fname" Value="<?=$res['Firstname']?>">
  Last name<sup class="text-danger">*</sup> <input type="text" class="form-control" required name="Lname" Value="<?=$res['LastName']?>">
  Age <sup class="text-danger">*</sup> <input type="number" class="form-control" required name="Age" Value="<?=$res['Age']?>">
  PostId <sup class="text-danger">*</sup> <input type="number" class="form-control" required name="Post" Value="<?=$res['postId']?>"readonly>
  National Id <sup class="text-danger">*</sup> <input type="text" class="form-control" max="16" min="16" required name="Nid" Value="<?=$res['NID']?>">
  Date of birth <sup class="text-danger">*</sup> <input type="date" class="form-control" required name="Date" Value="<?=$res['DateOfBirth']?>">
 <input type="submit" value="Change" class="btn btn-outline-primary px-3 my-3" name="Edite-candidate">
      
</div>
</form>
    </div>
</div>
    </div>
</section>
<?php
include "footer.php";
?>
</body>
</html>