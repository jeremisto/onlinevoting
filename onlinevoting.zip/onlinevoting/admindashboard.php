<?php
require_once"authentication.php";
require_once"auth.php";

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/bootstrap.min.css">
</head>
<body background="plofilespc/vote.png">       
     <div class="text-center">
            <h1><font color="darkblue" size="5">Mobile and Online Voting System</h1></font>
            <hr>
    <div class="m-3">

    <?php
    include "header1.php";
    ?>
<hr>
<div class="m-2 row">
    <div class="col-lg-2 col-sm-7">
    </div>
    <div class="col-lg-8 col-sm-12 p-2">
<section style="min-height:100px">
     <?php include"connection.php";
     $r1=mysqli_fetch_array(mysqli_query($conn,"SELECT count(*) From candidate"));
     $r2=mysqli_fetch_array(mysqli_query($conn,"SELECT count(*) From votters"));
     $r3=mysqli_fetch_array(mysqli_query($conn,"SELECT count(*) From post"));
     ?>
 <table class="table table-striped my-1" border="5"><br>
    <tr bgcolor="darkblue"><th colspan="3" style="color:white;"><center>All Numbers of Candidates,Voters and Posts are availlable Now!</center></th></tr>
        
<tr bgcolor="darkblue">
    <th style="color: white;">whole candidates</th>
    <th style="color: white;">whole voters</th>
    <th style="color: white;">available Posts</th>
</tr>    
<tr bgcolor="white">
    <td><b><?=$r1['count(*)']?></td>
    <td><b><?=$r2['count(*)']?></td>
    <td><b><?=$r3['count(*)']?></td>
</tr>
 </table>
    </div>
</div>
    </div>
</section>
<?php
    include "footer.php";
    ?>

</body>
</html>