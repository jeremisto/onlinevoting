<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title></title>
    <style>
      nav #navigation ul li a{
        color:white;
        padding: 3px;
        font-size:17px;
        border-radius:1px;
        border:solid 1px white;
        
        margin:9px;
        margin-right:30px;
        background-color: darkblue;
         
      }
  nav #navigation ul{
    display: flex;
    justify-content: space-between;
  }
      nav {
        justify-content: space-between;
        
      }
    </style>
</head>
<body>
<div class="nvb">
<nav class="navbar navbar-expand-md navbar-dark">
          <div class="navbar-brand">
            <font size="5"><b> M-ov-S</b></font>
          </div>

          <button
            class="navbar-toggler"
            type="button"
            data-bs-toggle="collapse"
            data-bs-target="#navigation"
          >
            <span class="navbar-toggler-icon"></span>
          </button>

          <div class="collapse navbar-collapse" id="navigation">
            <ul class="navbar-nav ms-auto">
               <li class="nav-item">
              <a href="changvot.php" class="col">change_password</a>
              </li>
              <li class="nav-item">
                <a onclick="return confirm('Are you sure you want to log out?');"href="logout.php">logout</b></a></button>
              </li>
            </ul>
          </div>  
          </div>  
    </nav>
    </div>  
    </div>
    <script src="js/bootstrap.min.js"></script>
</body>
</html>