<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title></title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/bootstrap.min.css">
</head>
<body background="plofilespc/vote.png">       
     <div class="text-center">
            <h1><font color="darkblue" size="5">Mobile and Online Votting System</h1></font>
            <hr>
    <div class="m-3">

    <?php
    include "header3.php";
    ?>
    <hr>

<section style="min-height:100px">
    

<div class="m-2 row">
    <div class="col-lg-2 col-sm-7">
    </div>
    <div class="col-lg-8 col-sm-12 p-2">
     <div class="form-group p-3 m-2">
      <center><label class="bg-primary card m-6 p-3"><b><font size="5"><b>Change password here</label></font>
      </center><form action="changevot.php" method="post" class="card m-6 p-3">
     <div class="form-group p-3 m-2">
    <label for="email">old password</label>
    <input type="password" class="form-control" placeholder="enter old password" name="oldpass">
  </div>
  <div class="form-group p-3 m-2">
    <label for="pwd">New Password:</label>
    <input type="password" class="form-control" name="psw1" placeholder="new password">
  </div>
  <div class="form-group p-3 m-2">
    <label for="pwd"> confirm Password:</label>
    <input type="password" class="form-control" name="psw2" placeholder="confirm password">
  </div>
 <center> <input type="submit" class="btn btn-primary" value="change" name="change"></center>
     </form>
    </div>
</div>
    </div>
</section>
    <?php
    include "footer.php";
    ?>
</body>
</html>