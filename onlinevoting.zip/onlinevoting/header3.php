<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title></title>
    <title></title>
    <style>
      nav #navigation ul li a{
        color:white;
        padding: 2px;
        font-size:20px;
        border-radius:1px;
        border:solid 1px white;
      
        margin:16px;
         
         
      }
  nav #navigation ul{
    display: flex;
    justify-content: space-between;
  }
      nav {
        justify-content: space-between;
        
        margin-left:-5px;
      }
    </style>
</head>
<body>

<div class="nvb">
<nav class="navbar navbar-expand-md navbar-dark">
          <div class="navbar-brand">
                <font size="5"><b> M-ov-S</b></font>
          </div>

          <button
            class="navbar-toggler"
            type="button"
            data-bs-toggle="collapse"
            data-bs-target="#navigation"
          >
            <span class="navbar-toggler-icon"></span>
          </button>

          <div class="collapse navbar-collapse" id="navigation">
            <ul class="navbar-nav ms-auto">
              <li class="nav-item">
              <a href="vottersdashboard.php" class="active col"><i class="fa fa-home"></i>Back</a>
              </li>
              </li><br>
              </li>
            </ul>
          </div>  
          </div>  
    </nav>
    </div>  
    </div>
    <script src="js/bootstrap.min.js"></script>
</body>
</html>