<?php
require_once"authentication.php";
require_once"auth.php";

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/bootstrap.min.css">
</head>

<body background="plofilespc/vote.png">       
     <div class="text-center">
            <h1><font color="darkblue" size="5">Mobile and Online Voting System</h1></font>
            <hr>
             <?php
    include "header4.php";
    ?>
            <hr>
        <div class="text-light text-center "> 
        &ensp;&ensp;&ensp;&ensp;&ensp;<h1 style="color:white; background-color:black;"> On this Voting Pannel Choose the posts are below!</div></h1>&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;
     
         
        <div class="d-flex text-center "  style="justify-content:; font:size 10;"><br><br>

        <p><?php
    include "connection.php";
$qr=mysqli_query($conn,"SELECT * From post");
while($res=mysqli_fetch_array($qr)){
echo" <a href='vote.php?post=$res[postId]' class='btn btn-outline-light btn-lg bg-primary'>$res[postName]</a> </li>";
}
?></h2></div></p>
      
        <section style="min-height:100px">
        <div class="m-3">
    </div>
</section>
<?php
include "footer.php";
?>
</body>
</html>