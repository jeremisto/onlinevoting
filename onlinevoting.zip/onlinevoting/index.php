<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title></title>
    <link rel="stylesheet" href="/css/style.css">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body background="plofilespc/vote.png">       
     <div class="text-center">
            <h1><font color="darkblue" size="5">Mobile and Online Voting System</h1></font>
            <hr>
        </div>
    <div class="m-3">

    <?php
    include "header.php";
    ?>
    <hr>

<section style="min-height:350px">
    

<div class="m-3 row">
    <div class="col-lg-2 col-sm-12"> 
    </div>
    <div class="col-lg-2 col-sm-12 py-5">
     <h5><font color="blue"> <b><br><br><br><br><BR><BR> Welcome to online Voting system
     fast and reliable  way to choose
     your leader!!!!!!!!!!!!</b></h5>
     This platform will help you to choose your leader online 
      this is reliable and more secured.<br>
      you have full access to choose leader on all availlable posts</font>
     <br>
     <div>
        <a href="#" class="btn btn-success p-2 m-3">Let Start >>></a>
     
    </div>
      
    </div>
</div>
    </div>
</section>
<?php
    include "footer.php";
    ?>
</body>
</html>